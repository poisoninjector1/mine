xmrig.exe -a gr -o stratum+tcp://ghostrider.unmineable.com:3333 -u Rubel1164 -p x 
pause